import Home from "./pages/Home";

function App() {
  return (
    <div className="min-h-screen bg-gray-50 flex flex-col items-center justify-center p-8">
      <Home />
    </div>
  );
}

export default App;
